package com.axis;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.axis.entity.Account;
import com.axis.entity.Loan;
import com.axis.entity.Transaction;
import com.axis.repository.AccountRepository;
import com.axis.repository.CustomerTransactionRepository;
import com.axis.repository.LoanRepository;
import com.axis.repository.UserRepository;
import com.axis.service.UserDetailsServiceImpl;

@SpringBootTest
class LoanServiceApplicationTests {

	@Autowired
	private UserDetailsServiceImpl service;

	@MockBean
	private UserRepository ur;
	
	@MockBean
	private AccountRepository ar;
	
	@MockBean
	private CustomerTransactionRepository ctr;
	
	@MockBean
	private LoanRepository lr;
	
	 @Test
	    public void testFetchAllMyLoans() {
	        int accountId = 1; 
	        List<Loan> loans = new ArrayList<>(); 

	        // Mock the behavior of the LockerRepository
	        when(lr.getAllMyLoansByAccountId(accountId)).thenReturn(loans);

	        // Call the service method
	        List<Loan> result = service.fetchAllMyLoans(accountId);

	        // Verify that the LockerRepository method was called once with the correct accountId
	        verify(lr, times(1)).getAllMyLoansByAccountId(accountId);

	        // Verify that the returned list of loans is the same as the one from the repository
	        assertEquals(loans, result);
	    }
	 
	 @Test
	    public void testFetchAllLoans() {
	        List<Loan> loans = new ArrayList<>(); 

	        // Mock the behavior of the LockerRepository
	        when(lr.findAll()).thenReturn(loans);

	        // Call the service method
	        List<Loan> result = service.fetchAllLoans();

	        // Verify that the LockerRepository method was called once
	        verify(lr, times(1)).findAll();

	        // Verify that the returned list of loans is the same as the one from the repository
	        assertEquals(loans, result);
	    }
	 
	 @Test
	    public void testActiveLoanStatus() {
	        int loanId = 123; 
	        
	        // Call the service method
	        service.activeLoanStatus(loanId);

	        // Verify that the LockerRepository method was called once with the correct loanId
	        verify(lr, times(1)).updateLoanStatus(loanId);
	    }
	 
	    @Test
	    public void testFetchAllPendingLoans() {
	        // Create a list of loans with a specific status
	        List<Loan> pendingLoans = new ArrayList<>();
	        pendingLoans.add(new Loan("Personal", 1000.0, 100.0, null, null, 12, "PENDING", null));
	        pendingLoans.add(new Loan("Home", 2000.0, 200.0, null, null, 24, "PENDING", null));

	        // Mock the behavior of the LockerRepository
	        when(lr.findByStatusPending()).thenReturn(pendingLoans);

	        // Call the service method
	        List<Loan> result = service.fetchAllPendingLoans();

	        // Verify the result
	        assertEquals(2, result.size()); // Assuming the list contains 2 pending loans
	        assertEquals("PENDING", result.get(0).getStatus());
	        assertEquals("PENDING", result.get(1).getStatus());

	        // Verify that the LockerRepository method was called once
	        verify(lr, times(1)).findByStatusPending();
	    }
	    
	    @Test
	    public void testCloseLoan() {
	        int loanId = 123; 

	        // Call the service method
	        service.closeLoan(loanId);

	        // Verify that the foreCloseLoan method was called with the correct loan ID
	        verify(lr, times(1)).foreCloseLoan(loanId);
	    }

	    @Test
	    public void testFindLoanByLoanId() {
	        int loanId = 123; 

	        
	        Loan loan = new Loan();
	        loan.setLoanid(loanId);
	        loan.setLoantype("Personal Loan");
	        

	        // Use Mockito's when method to specify the behavior when findById is called
	        when(lr.findById(loanId)).thenReturn(loan);

	        // Call the service method
	        Loan foundLoan = service.findLoanByLoanId(loanId);

	        // Verify that the findById method was called once with the correct loan ID
	        verify(lr, times(1)).findById(loanId);

	        // Verify that the returned Loan object matches the expected Loan object
	        assertNotNull(foundLoan);
	        assertEquals(loanId, foundLoan.getLoanid());
	        assertEquals("Personal Loan", foundLoan.getLoantype());
	        // Verify other properties as needed
	    }
	    
	    @Test
	    public void testLoanDeposit() {
	        double amount = 1000.0;
	        String loantype = "Personal Loan";

	        // Create a sample Account object
	        Account account = new Account();
	        account.setAccid(1);
	       

	        // Call the service method
	        service.loanDeposit(amount, loantype, account);

	        // Use ArgumentCaptor to capture the Transaction object that is saved
	        ArgumentCaptor<Transaction> transactionCaptor = ArgumentCaptor.forClass(Transaction.class);
	        verify(ctr, times(1)).save(transactionCaptor.capture());

	        // Retrieve the captured Transaction object
	        Transaction savedTransaction = transactionCaptor.getValue();

	        // Verify that the Transaction object is not null
	        assertNotNull(savedTransaction);

	        // Verify that the properties of the saved Transaction object match the expected values
	        assertEquals(amount, savedTransaction.getAmount());
	        assertEquals(loantype + " Deposit", savedTransaction.getDescription());
	        assertEquals("CREDIT", savedTransaction.getTransactiontype());
	        assertEquals(account, savedTransaction.getAccount());
	        
	    }
	    
	    @Test
	    public void testLoanPayment() {
	        String loantype = "Personal Loan";
	        double loanemi = 500.0;
	        int accid = 1;
	        int userid = 100;

	        // Create a sample Account object
	        Account account = new Account();
	        account.setAccid(accid);
	       

	        // Mock the behavior of accountRepository and transactionRepository
	        when(ar.findAccountByUserId(userid)).thenReturn(account);

	        // Call the service method
	        service.loanPayment(loantype, loanemi, accid, userid);

	        // Verify that accountRepository.findAccountByUserId() was called once with the correct user id
	        verify(ar, times(1)).findAccountByUserId(userid);

	        // Use ArgumentCaptor to capture the Transaction object that is saved
	        ArgumentCaptor<Transaction> transactionCaptor = ArgumentCaptor.forClass(Transaction.class);
	        verify(ctr, times(1)).save(transactionCaptor.capture());

	        // Retrieve the captured Transaction object
	        Transaction savedTransaction = transactionCaptor.getValue();

	        // Verify that the Transaction object is not null
	        assertNotNull(savedTransaction);

	        // Verify that the properties of the saved Transaction object match the expected values
	        assertEquals(loanemi, savedTransaction.getAmount());
	        assertEquals(loantype + " EMI Withdrawal", savedTransaction.getDescription());
	        assertEquals("DEBIT", savedTransaction.getTransactiontype());
	        assertEquals(account, savedTransaction.getAccount());
	        
	    }

}
