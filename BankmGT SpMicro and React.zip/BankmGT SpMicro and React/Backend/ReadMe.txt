Eureka client

http://localhost:8761/