// import React from 'react'
// import Navbar1 from './Components1/Navbar1'
// import Header1 from './pages/Header1'
// import About1 from './pages/About1'
// import Footer from './Components/Footer'

// function Home2() {
//   return (
//     <>
//     <Navbar1></Navbar1>
//     <Header1></Header1>
//     <About1></About1>
//     <Footer></Footer>
//     </>
//   )
// }

// export default Home2;