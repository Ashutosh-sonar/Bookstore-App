import React from "react";
import transaction from "./assets/transaction.jpg";
import loan from "./assets/loan.jpg";
import credit from "./assets/credit.jpg";
import gift from "./assets/gift.jpg";
import loacker from "./assets/loacker.jpg";
const Sdata = [
    {
        sname: "TRANSACTION",
        imgscr: transaction,

    },
    {
        sname: "LOAN",
        imgscr: loan,

    },
    {
        sname: "CREDIT CARD",
        imgscr: credit,

    },
    {
        sname: "GIFT CARD",
        imgscr: gift,

    },
    {
        sname: "LOCKER",
        imgscr: loacker,

    },
]
export default Sdata;













