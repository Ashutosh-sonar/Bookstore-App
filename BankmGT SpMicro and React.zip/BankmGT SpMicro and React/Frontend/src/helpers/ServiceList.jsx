import Pepperoni from "../assets/carlos-muza-hpjSkU2UYSU-unsplash.jpg";
import Margherita from "../assets/charanjeet-dhiman-mHusyBu4bxM-unsplash.jpg";
import PedroTechSpecial from "../assets/john-schnobrich-FlPc9_VocJ4-unsplash.jpg";
import Vegan from "../assets/mailchimp-04X1Yp9hNH8-unsplash.jpg";
import Pineapple from "../assets/john-schnobrich-2FPjlAyMQTA-unsplash.jpg";
import Expensive from "../assets/microsoft-edge-Px0X7g1mc8k-unsplash.jpg";

export const ServiceList = [
  {
    name: "Stocks and bonds",
    image: Pepperoni
  },
  {
    name: "Online Banking",
    image: Margherita
  },
  {
    name: "Home loans",
    image: PedroTechSpecial
  },
  {
    name: "Mutual funds",
    image: Vegan
  },
  {
    name: "Business credit cards",
    image: Pineapple
  },
  {
    name: "Retirement planning",
    image: Expensive
  },
];
