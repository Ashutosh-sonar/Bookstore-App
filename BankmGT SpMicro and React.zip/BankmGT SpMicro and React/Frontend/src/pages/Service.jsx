// import React from "react";
// import { ServiceList } from "../helpers/ServiceList";
// import ServiceItem from "../Components/ServiceItem";
// import "../styles/Service.css";

// function Menu() {
//   return (
//     <div className="menu">
//       <h1 className="menuTitle">Our Services</h1>
//       <div className="menuList">
//         {ServiceList.map((menuItem, key) => {
//           return (
//             <ServiceItem
//               key={key}
//               image={menuItem.image}
//               name={menuItem.name}
//             />
//           );
//         })}
//       </div>
//     </div>
//   );
// }

// export default Menu;
